print('hellow chahcha')
print('life is all about move on')
print ('jkjijisjoijdi')