package myNewproject;

import java.util.Scanner;

public class taking_charecter {

	public static void main(String[] args) {
		
		System.out.println("enter a charecter");
		Scanner sc=new Scanner(System.in);
		char c= sc.nextLine().charAt(0);
		
		System.out.println(c);
		

	}

}
