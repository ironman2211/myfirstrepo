

for()
    print('hello')
    print('bhims')